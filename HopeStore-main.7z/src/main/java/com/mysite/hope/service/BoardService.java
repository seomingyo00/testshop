package com.mysite.hope.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysite.hope.entity.Board;
import com.mysite.hope.repository.BoardRepository;

@Service
public class BoardService {

    @Autowired
    private BoardRepository boardRepository;

    // 게시글 전체 목록 조회
    public List<Board> getAllBoards() {
        return boardRepository.findAll();
    }

    // 게시글 생성
    public void createBoard(String title, String content) {
        Board board = new Board(title, content);
        boardRepository.save(board);
    }
}
