package com.mysite.hope.service;

import com.mysite.hope.entity.Comment;
import com.mysite.hope.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    public void createComment(Long boardId, String content, Boolean isAdmin) {
        if (!isAdmin) {
            throw new RuntimeException("관리자만 댓글을 작성할 수 있습니다.");
        }
        Comment comment = new Comment(boardId, content, true);
        commentRepository.save(comment);
    }

    public void updateComment(Long id, String content, Boolean isAdmin) {
        if (!isAdmin) {
            throw new RuntimeException("관리자만 댓글을 수정할 수 있습니다.");
        }
        Comment comment = commentRepository.findById(id).orElseThrow();
        comment.setContent(content);
        commentRepository.save(comment);
    }
}
