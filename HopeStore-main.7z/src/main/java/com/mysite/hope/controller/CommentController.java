package com.mysite.hope.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mysite.hope.service.CommentService;

@RestController
@RequestMapping("/comment")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("/create")
    public ResponseEntity<String> createComment(@RequestParam Long boardId, @RequestParam String content, @RequestParam Boolean isAdmin) {
        commentService.createComment(boardId, content, isAdmin);
        return ResponseEntity.ok("댓글이 작성되었습니다.");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateComment(@PathVariable Long id, @RequestParam String content, @RequestParam Boolean isAdmin) {
        commentService.updateComment(id, content, isAdmin);
        return ResponseEntity.ok("댓글이 수정되었습니다.");
    }
}
