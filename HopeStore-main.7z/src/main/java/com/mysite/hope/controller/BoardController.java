package com.mysite.hope.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysite.hope.service.BoardService;

@Controller
@RequestMapping("/board")
public class BoardController {

    @Autowired
    private BoardService boardService;

    // 게시판 목록 페이지
    @GetMapping
    public String showBoardList(Model model) {
        model.addAttribute("boards", boardService.getAllBoards());
        return "boardList"; // boardList.html 템플릿으로 이동
    }

    // 게시글 작성 페이지
    @GetMapping("/create")
    public String showCreateBoardForm() {
        return "createBoard"; // createBoard.html 템플릿으로 이동
    }

    // 게시글 작성 처리
    @PostMapping("/create")
    public String createBoard(@RequestParam String title, @RequestParam String content) {
        boardService.createBoard(title, content);
        return "redirect:/board"; // 게시판 목록 페이지로 리다이렉트
    }
}
