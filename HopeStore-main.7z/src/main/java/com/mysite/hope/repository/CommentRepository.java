package com.mysite.hope.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mysite.hope.entity.Comment;

public interface CommentRepository extends JpaRepository<Comment, Long> {
}
