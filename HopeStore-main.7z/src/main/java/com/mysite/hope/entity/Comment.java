package com.mysite.hope.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long boardId;
    private String content;
    private Boolean isAdmin;

    private LocalDateTime createdAt;

    public Comment() {}

    public Comment(Long boardId, String content, Boolean isAdmin) {
        this.boardId = boardId;
        this.content = content;
        this.isAdmin = isAdmin;
        this.createdAt = LocalDateTime.now();
    }

    // Getters and setters
}
