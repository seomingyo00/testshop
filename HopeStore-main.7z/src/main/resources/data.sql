-- 게시판 예시 데이터
INSERT INTO board (title, content, created_at, updated_at)
VALUES ('첫 번째 게시글', '이것은 첫 번째 게시글의 내용입니다.', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- 댓글 예시 데이터
INSERT INTO comment (board_id, content, is_admin, created_at)
VALUES (1, '첫 번째 댓글입니다.', true, CURRENT_TIMESTAMP);
